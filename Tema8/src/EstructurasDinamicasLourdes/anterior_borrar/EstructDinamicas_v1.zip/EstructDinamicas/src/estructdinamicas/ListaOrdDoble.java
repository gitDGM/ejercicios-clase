/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estructdinamicas;

/**
 *
 * @author alumno
 */
public class ListaOrdDoble {
    private class Nodo {
        String dato;
        Nodo anterior, siguiente;
    }
    private Nodo inicio, fin;
    
    ListaOrdDoble() {
        this.inicio = null;
        this.fin = null;
    }
    
    //indica si la lista está vacía (true)
    public boolean esVacia() {
        boolean vacia = false;
        if(inicio == null)
            vacia = true;
        return vacia;
    }
    
    //devuelve el tamaño de la lista
    public int obtenerTam() {
        int tam = 0;
        if(!esVacia()){
            Nodo recorre = inicio;
            while(recorre != null) {
                tam++;
                recorre = recorre.siguiente;
            }
        }
        return tam;
    }
    
    //añade un elemento ordenado, de forma ascendente
    public void agregarNodoAsc(String informacion) {
        Nodo nuevo = new Nodo();
        nuevo.dato = informacion;
        if(esVacia()){ 
            nuevo.anterior = null;
            nuevo.siguiente = null;
            inicio = nuevo;
            fin = nuevo;
        } else { // existe lista
            if(informacion.compareToIgnoreCase(inicio.dato) < 0) { //inserta al inicio
                nuevo.anterior = null;
                nuevo.siguiente = inicio;
                inicio.anterior = nuevo;
                inicio = nuevo;
            } else {
                if(informacion.compareToIgnoreCase(fin.dato) > 0) { //inserta al final
                    nuevo.anterior = fin;
                    nuevo.siguiente = null;
                    fin.siguiente = nuevo;
                    fin = nuevo;
                } else { //entre dos ya existentes (antes de recorre)
                    Nodo recorre = inicio;
                    while(recorre.siguiente != null && informacion.compareToIgnoreCase(recorre.dato) >= 0){
                        recorre = recorre.siguiente;
                    }
                    nuevo.anterior = recorre.anterior;
                    nuevo.siguiente = recorre;
                    (recorre.anterior).siguiente = nuevo;
                    recorre.anterior = nuevo;
                }
            }
        }
    }
    
    //añade un elemento ordenado, de forma descendente
    public void agregarNodoDesc(String informacion) {
        Nodo nuevo = new Nodo();
        nuevo.dato = informacion;
        if(esVacia()){ 
            nuevo.anterior = null;
            nuevo.siguiente = null;
            inicio = nuevo;
            fin = nuevo;
        } else { // existe lista
            if(inicio.dato.compareToIgnoreCase(informacion) < 0) { //inserta al inicio
                nuevo.anterior = null;
                nuevo.siguiente = inicio;
                inicio.anterior = nuevo;
                inicio = nuevo;
            } else {
                if(fin.dato.compareToIgnoreCase(informacion) > 0) { //inserta al final
                    nuevo.anterior = fin;
                    nuevo.siguiente = null;
                    fin.siguiente = nuevo;
                    fin = nuevo;
                } else { //entre dos ya existentes (antes de recorre)
                    Nodo recorre = inicio;
                    while(recorre.siguiente != null && recorre.dato.compareToIgnoreCase(informacion) >= 0){
                        recorre = recorre.siguiente;
                    }
                    nuevo.anterior = recorre.anterior;
                    nuevo.siguiente = recorre;
                    (recorre.anterior).siguiente = nuevo;
                    recorre.anterior = nuevo;
                }
            }
        }
    }  
    
    private void liberarMemoria(Nodo borrado) {
        borrado.dato = null;
        borrado.anterior = null;
        borrado.siguiente = null;
    }
    
    //elimina el elemento indicado en posicion
    public String eliminarNodo(int posicion) {
        String informacion = "";
        Nodo borrado = inicio;
        if(esVacia()){
            System.err.println("Lista vacía");
        } else {
            if(posicion >= 0 && posicion < obtenerTam()) {
                if(posicion == 0) {
                    if(inicio != fin) { //hay al menos 2 elementos
                        inicio = inicio.siguiente;
                        inicio.anterior = null;
                    } else { //solo queda el que quiero borrar
                        inicio = null;
                        fin = null;
                    }
                    //liberarMemoria(borrado);
                } else {
                    if(posicion == (obtenerTam() -1)){ //borro el ultimo
                        borrado = fin;
                        (fin.anterior).siguiente = null;
                        fin = fin.anterior;
                        //liberarMemoria(borrado);
                    } else { //borro un nodo que está entre dos (y no son ni inicio ni fin)
                        Nodo recorre = inicio;
                        for(int i = 0; i < posicion; i++){
                            recorre = recorre.siguiente;
                        }
                        borrado = recorre;
                        (recorre.anterior).siguiente = recorre.siguiente; //anterior de recorre apunta a siguiente a recorre
                        (recorre.siguiente).anterior = recorre.anterior; //siguiente a recorre apunta al anterior de recorre
                    }
                }
                informacion = borrado.dato;
                liberarMemoria(borrado);                    
            } else {
                System.err.println("Posición no válida");
            }                
        }        
        return informacion;
    }

    //extraer nodo que contiene la informacion indicada
    public String eliminarNodo(String informacion) {
        String borro = "";
        
        return borro;
    }
    
    public void imprimirLista() {
        if(esVacia()) {
            System.err.println("Lista vacía");
        } else {
            System.out.println("Elementos de la lista (del primero al último):");
            Nodo recorre = inicio;
            while(recorre != null) {
                System.out.print(recorre.dato + "\t");
                recorre = recorre.siguiente;
            }
            System.out.println("\nElementos de la lista (del último al último):");
            recorre = fin;
            while(recorre != null) {
                System.out.print(recorre.dato + "\t");
                recorre = recorre.anterior;
            }
            System.out.println();
        }
    }
}
