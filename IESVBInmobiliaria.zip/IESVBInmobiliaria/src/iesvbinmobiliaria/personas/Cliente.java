/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iesvbinmobiliaria.personas;

/**
 *
 * @author alumno
 */
public class Cliente extends Persona {

    public Cliente(int idPersona, String nombre, String apellidos, String dni, String telefono) {
        super(idPersona, nombre, apellidos, dni, telefono);
    }

}
